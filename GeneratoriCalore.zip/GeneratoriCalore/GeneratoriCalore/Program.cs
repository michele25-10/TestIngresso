﻿using System;

namespace GeneratoriCalore
{
    class Program
    {
        class GeneratoreCalore
        {
            protected double rendimento;
            protected double installazione;
            protected double prezzo;
            protected double SMCKWh;
            public GeneratoreCalore(double rendimento, double installazione, double prezzo, double SMCKWh)
            {
                this.rendimento = rendimento;
                this.installazione = installazione;
                this.prezzo = prezzo;
                this.SMCKWh = SMCKWh;
            }
            
            public virtual double OmogeneitaConsumo(double consumo) //In base al dispositivo in uso riporta gli SMC o i KWH ridimensionati in base al rendimento del  generatore che si possiede
            {
                return consumo * rendimento;
            }
            public virtual double CalcoloBolletta(double mediaGas)  //Calcola la bolletta del generatore di calore in esame
            {
                return (mediaGas / rendimento);
            }

            public virtual double CalcoloTotaleSpesa()  //Calcola la somma del costo di installazione ed il prezzo del generatore di calore
            {
                return installazione + prezzo;
            }
        
        }

        class Caldaia : GeneratoreCalore
        {
            public Caldaia(double rendimento, double installazione, double prezzo, double SMCKWh) : base(rendimento, installazione, prezzo, SMCKWh)
            {

            }
            public override double OmogeneitaConsumo(double consumo)
            {
                return consumo * rendimento;
            }
            public override double CalcoloBolletta(double mediaGas)
            {
                return ((mediaGas / rendimento) * 1.05) + 213;
            }
            public override double CalcoloTotaleSpesa()
            {
                return installazione + prezzo;
            }
        }

        class CaldaiaCondensazione : GeneratoreCalore
        {
            public CaldaiaCondensazione(double rendimento, double installazione, double prezzo, double SMCKWh) : base(rendimento, installazione, prezzo, SMCKWh)
            {

            }
            public override double OmogeneitaConsumo(double consumo)
            {
                return consumo * rendimento;
            }
            public override double CalcoloBolletta(double mediaGas)
            {
                return ((mediaGas / rendimento) * 1.05) + 213;
            }
            public override double CalcoloTotaleSpesa()
            {
                return installazione + prezzo;
            }
        }

        class PompaCaloreBuona : GeneratoreCalore
        {
            public PompaCaloreBuona(double rendimento, double installazione, double prezzo, double SMCKWh) : base(rendimento, installazione, prezzo, SMCKWh)
            {

            }
            public override double OmogeneitaConsumo(double consumo)
            {
                return consumo * rendimento;
            }
            public override double CalcoloBolletta(double mediaElett)
            {
                return (((mediaElett * SMCKWh) / rendimento) * 0.275) + 213;
            }
            public override double CalcoloTotaleSpesa()
            {
                return installazione + prezzo;
            }
        }
        class PompaCaloreEco : GeneratoreCalore
        {
            public PompaCaloreEco(double rendimento, double installazione, double prezzo, double SMCKWh) : base(rendimento, installazione, prezzo, SMCKWh)
            {

            }
            public override double OmogeneitaConsumo(double consumo)
            {
                return consumo * rendimento;
            }
            public override double CalcoloBolletta(double mediaElett)
            {
                return (((mediaElett * SMCKWh) / rendimento) * 0.275) + 213;
            }
            public override double CalcoloTotaleSpesa()
            {
                return installazione + prezzo;
            }
        }

        class StufaElettrica : GeneratoreCalore
        {
            public StufaElettrica(double rendimento, double installazione, double prezzo, double SMCKWh) : base(rendimento, installazione, prezzo, SMCKWh)
            {

            }
            public override double OmogeneitaConsumo(double consumo)
            {
                return consumo * rendimento;
            }
            public override double CalcoloBolletta(double mediaElett)
            {
                return (((mediaElett * SMCKWh) / rendimento) * 0.275) + 213;
            }
            public override double CalcoloTotaleSpesa()
            {
                return installazione + prezzo;
            }
        }

        class Famiglia 
        {
            private string cognome;
            private string indirizzo;

            public Famiglia (string cognome, string indirizzo)
            {
                this.cognome = cognome;
                this.indirizzo = indirizzo;
            }

            public string Convenienza(double bollettaAttuale, double bollettaIpotetica, double prezzoGeneratore)    //Calcola l'ammortizzamento del dispositivo e valuta l'addove sia più conveniente cambiare o meno dispositivo
            {
                if(bollettaAttuale <= bollettaIpotetica)
                {
                    return "E' maggiormente conveniente mantenere il generatore di calore attuale";
                }
                else
                {
                    double risparmio = bollettaAttuale - bollettaIpotetica;
                    double anni = prezzoGeneratore/risparmio;

                    if(anni > 20)
                    {
                        return "l'ammortizzamento supera i 20 anni, non è conveniente";

                    }

                    return "La spesa verrebbe ammortizzata in: " + Convert.ToString(anni);
                }
            }
            public string ConvenienzaBolletta(double caldaiaBol, double caldaiaCondBol, double pompaCaloreBuonaBol, double pompaCaloreEcoBol, double stufaBol)  //Calcola la bolletta più conveniente sul lungo termine facendo dei controlli sui valori tramite if
            {
                if(caldaiaBol <= caldaiaCondBol && caldaiaBol <= pompaCaloreBuonaBol && caldaiaBol <= pompaCaloreEcoBol && caldaiaBol <= stufaBol)
                {
                    return "La bolletta più conveniente è quella della caldaia tradizionale: "+caldaiaBol.ToString()+" euro";
                }
                if (caldaiaCondBol <= caldaiaBol && caldaiaCondBol <= pompaCaloreBuonaBol && caldaiaCondBol <= pompaCaloreEcoBol && caldaiaCondBol <= stufaBol)
                {
                    return "La bolletta più conveniente è quella della caldaia a condensazione: " + caldaiaCondBol.ToString() + " euro";
                }
                if (pompaCaloreBuonaBol <= caldaiaBol && pompaCaloreBuonaBol <= caldaiaCondBol && pompaCaloreBuonaBol <= pompaCaloreEcoBol && pompaCaloreBuonaBol <= stufaBol)
                {
                    return "La bolletta più conveniente è quella della pompa di calore di buon livello: " + pompaCaloreBuonaBol.ToString() + " euro";
                }
                if (pompaCaloreEcoBol <= caldaiaBol && pompaCaloreEcoBol <= caldaiaCondBol && pompaCaloreEcoBol <= pompaCaloreBuonaBol && pompaCaloreEcoBol <= stufaBol)
                {
                    return "La bolletta più conveniente è quella della pompa di calore di buon livello: " + pompaCaloreEcoBol.ToString() + " euro";
                }
                if (stufaBol <= caldaiaBol && stufaBol <= caldaiaCondBol && stufaBol <= pompaCaloreBuonaBol && stufaBol <= pompaCaloreEcoBol)
                {
                    return "La bolletta più conveniente è quella della pompa di calore di buon livello: " + stufaBol.ToString() + " euro";
                }
                return "0";
            }
        }


        static void Main(string[] args)
        {
            string cognome, indirizzo;
            double mediaGas, mediaElettricita;
            string tipoGeneratore;
            string res;
            bool controllo;

            //INIZIALIZZAZIONE CLASSI
            Caldaia caldaia = new Caldaia(0.9, 250, 1500, 10.7);
            CaldaiaCondensazione caldaiaCond = new CaldaiaCondensazione(1, 250, 1500, 10.7);
            PompaCaloreBuona pompaCaloreBuona = new PompaCaloreBuona(3.6, 800, 3000, 10.7);
            PompaCaloreEco pompaCaloreEco = new PompaCaloreEco(2.8, 600, 1000, 10.7);
            StufaElettrica stufa = new StufaElettrica(1, 500, 700, 10.7);

            //PRIME COMUNICAZIONI CON L'UTENTE
            Console.WriteLine("Inserisci cognome della famiglia:");
            cognome = Console.ReadLine();
            Console.WriteLine("Inserisci l'indirizzo di residenza:");
            indirizzo = Console.ReadLine();

            //INIZIALIZZAZIONE CLASSE FAMIGLIA
            Famiglia famiglia = new Famiglia(cognome, indirizzo);
            do
            {
                Console.WriteLine("Scegli il tuo metodo di riscaldamento\n" +
                              "Premi 1 per la caldaia tradizionale\n" +
                              "Premi 2 per la caldaia condensazione\n" +
                              "Premi 3 per pompa di calore di buon livello\n" +
                              "Premi 4 per la pompa di calore economica\n" +
                              "Premi 5 per la stufa elettrica\n");
                tipoGeneratore = Console.ReadLine(); //assunzione valore da tastiera
            } while (tipoGeneratore != "1" && tipoGeneratore != "2" && tipoGeneratore != "3" && tipoGeneratore != "4" && tipoGeneratore != "5");//viene ripetuto nel caso in cui vengano inseriti caratteri diversi da quelli del menù

            switch(tipoGeneratore)  //IN base al generatore di calore che si dispone verranno richiamati i vari metodi
            {
                case "1":
                    do
                    {
                        Console.WriteLine("Inserisci la media annuale di GAS che la famiglia consuma per scaldare casa:");
                        res = Console.ReadLine();
                        controllo = Double.TryParse(res, out mediaGas);
                    } while (!controllo || mediaGas < 0);
                    mediaGas = caldaia.OmogeneitaConsumo(mediaGas);

                    Console.WriteLine("----------------------------------------------------------------------------------------");
                    Console.WriteLine("TEMPO AMMORTIZZAMENTO");
                    Console.WriteLine("Rispetto alla caldaia a condensazione: " + famiglia.Convenienza(caldaia.CalcoloBolletta(mediaGas), caldaiaCond.CalcoloBolletta(mediaGas), caldaiaCond.CalcoloTotaleSpesa()));
                    Console.WriteLine("Rispetto alla pompa di calore di buon livello: " + famiglia.Convenienza(caldaia.CalcoloBolletta(mediaGas), pompaCaloreBuona.CalcoloBolletta(mediaGas), pompaCaloreBuona.CalcoloTotaleSpesa()));
                    Console.WriteLine("Rispetto alla pompa di calore economica: " + famiglia.Convenienza(caldaia.CalcoloBolletta(mediaGas), pompaCaloreEco.CalcoloBolletta(mediaGas), pompaCaloreEco.CalcoloTotaleSpesa()));
                    Console.WriteLine("Rispetto alla stufa elettrica: " + famiglia.Convenienza(caldaia.CalcoloBolletta(mediaGas), stufa.CalcoloBolletta(mediaGas), stufa.CalcoloTotaleSpesa()));
                    Console.WriteLine("----------------------------------------------------------------------------------------");

                    Console.WriteLine("CALCOLO BOLLETTA PIU' CONVENIENTE SUL LUNGO TERMINE");
                    Console.WriteLine(famiglia.ConvenienzaBolletta(caldaia.CalcoloBolletta(mediaGas), caldaiaCond.CalcoloBolletta(mediaGas), pompaCaloreBuona.CalcoloBolletta(mediaGas), pompaCaloreEco.CalcoloBolletta(mediaGas), stufa.CalcoloBolletta(mediaGas)));
                    Console.WriteLine("----------------------------------------------------------------------------------------");

                    break;

                case "2":
                    do
                    {
                        Console.WriteLine("Inserisci la media annuale di GAS che la famiglia consuma per scaldare casa:");
                        res = Console.ReadLine();
                        controllo = Double.TryParse(res, out mediaGas);
                    } while (!controllo || mediaGas < 0);       //Controllo per capire se il numero inserito è davvero un numero e non una stringa e per vedere se è maggiore di 0
                    mediaGas = caldaiaCond.OmogeneitaConsumo(mediaGas);

                    Console.WriteLine("----------------------------------------------------------------------------------------");
                    Console.WriteLine("TEMPO AMMORTIZZAMENTO");
                    Console.WriteLine("Rispetto alla caldaia tradizionale: " + famiglia.Convenienza(caldaiaCond.CalcoloBolletta(mediaGas), caldaia.CalcoloBolletta(mediaGas), caldaia.CalcoloTotaleSpesa()));
                    Console.WriteLine("Rispetto alla pompa di calore di buon livello: " + famiglia.Convenienza(caldaiaCond.CalcoloBolletta(mediaGas), pompaCaloreBuona.CalcoloBolletta(mediaGas), pompaCaloreBuona.CalcoloTotaleSpesa()));
                    Console.WriteLine("Rispetto alla pompa di calore economica: " + famiglia.Convenienza(caldaiaCond.CalcoloBolletta(mediaGas), pompaCaloreEco.CalcoloBolletta(mediaGas), pompaCaloreEco.CalcoloTotaleSpesa()));
                    Console.WriteLine("Rispetto alla stufa elettrica: " + famiglia.Convenienza(caldaiaCond.CalcoloBolletta(mediaGas), stufa.CalcoloBolletta(mediaGas), stufa.CalcoloTotaleSpesa()));
                    Console.WriteLine("----------------------------------------------------------------------------------------");

                    Console.WriteLine("CALCOLO BOLLETTA PIU' CONVENIENTE SUL LUNGO TERMINE");
                    Console.WriteLine(famiglia.ConvenienzaBolletta(caldaia.CalcoloBolletta(mediaGas), caldaiaCond.CalcoloBolletta(mediaGas), pompaCaloreBuona.CalcoloBolletta(mediaGas), pompaCaloreEco.CalcoloBolletta(mediaGas), stufa.CalcoloBolletta(mediaGas)));
                    Console.WriteLine("----------------------------------------------------------------------------------------");

                    break;

                case "3":
                    do
                    {
                        Console.WriteLine("Inserisci la media annuale di ELETTRICITA' che la famiglia consuma:");
                        res = Console.ReadLine();
                        controllo = Double.TryParse(res, out mediaElettricita);
                    } while (!controllo || mediaElettricita < 0);
                    mediaGas = pompaCaloreBuona.OmogeneitaConsumo(mediaElettricita / 10.7);

                    Console.WriteLine("----------------------------------------------------------------------------------------");
                    Console.WriteLine("TEMPO AMMORTIZZAMENTO");
                    Console.WriteLine("Rispetto alla caldaia tradizionale: " + famiglia.Convenienza(pompaCaloreBuona.CalcoloBolletta(mediaGas), caldaia.CalcoloBolletta(mediaGas), caldaia.CalcoloTotaleSpesa()));
                    Console.WriteLine("Rispetto alla caldaia a condensazione: " + famiglia.Convenienza(pompaCaloreBuona.CalcoloBolletta(mediaGas), caldaiaCond.CalcoloBolletta(mediaGas), caldaiaCond.CalcoloTotaleSpesa()));
                    Console.WriteLine("Rispetto alla pompa di calore economica: " + famiglia.Convenienza(pompaCaloreBuona.CalcoloBolletta(mediaGas), pompaCaloreEco.CalcoloBolletta(mediaGas), pompaCaloreEco.CalcoloTotaleSpesa()));
                    Console.WriteLine("Rispetto alla stufa elettrica: " + famiglia.Convenienza(pompaCaloreBuona.CalcoloBolletta(mediaGas), stufa.CalcoloBolletta(mediaGas), stufa.CalcoloTotaleSpesa()));
                    Console.WriteLine("----------------------------------------------------------------------------------------");

                    Console.WriteLine("CALCOLO BOLLETTA PIU' CONVENIENTE SUL LUNGO TERMINE");
                    Console.WriteLine(famiglia.ConvenienzaBolletta(caldaia.CalcoloBolletta(mediaGas), caldaiaCond.CalcoloBolletta(mediaGas), pompaCaloreBuona.CalcoloBolletta(mediaGas), pompaCaloreEco.CalcoloBolletta(mediaGas), stufa.CalcoloBolletta(mediaGas)));
                    Console.WriteLine("----------------------------------------------------------------------------------------");

                    break;

                case "4":
                    do
                    {
                        Console.WriteLine("Inserisci la media annuale di ELETTRICITA' che la famiglia consuma:");
                        res = Console.ReadLine();
                        controllo = Double.TryParse(res, out mediaElettricita);
                    } while (!controllo || mediaElettricita < 0);
                    mediaGas = pompaCaloreEco.OmogeneitaConsumo(mediaElettricita / 10.7);

                    Console.WriteLine("----------------------------------------------------------------------------------------");
                    Console.WriteLine("TEMPO AMMORTIZZAMENTO");
                    Console.WriteLine("Rispetto alla caldaia tradizionale: " + famiglia.Convenienza(pompaCaloreEco.CalcoloBolletta(mediaGas), caldaia.CalcoloBolletta(mediaGas), caldaia.CalcoloTotaleSpesa()));
                    Console.WriteLine("Rispetto alla caldaia a condensazione: " + famiglia.Convenienza(pompaCaloreEco.CalcoloBolletta(mediaGas), caldaiaCond.CalcoloBolletta(mediaGas), caldaiaCond.CalcoloTotaleSpesa()));
                    Console.WriteLine("Rispetto alla pompa di calore di buon livello: " + famiglia.Convenienza(pompaCaloreEco.CalcoloBolletta(mediaGas), pompaCaloreBuona.CalcoloBolletta(mediaGas), pompaCaloreBuona.CalcoloTotaleSpesa()));
                    Console.WriteLine("Rispetto alla stufa elettrica: " + famiglia.Convenienza(pompaCaloreEco.CalcoloBolletta(mediaGas), stufa.CalcoloBolletta(mediaGas), stufa.CalcoloTotaleSpesa()));
                    Console.WriteLine("----------------------------------------------------------------------------------------");

                    Console.WriteLine("CALCOLO BOLLETTA PIU' CONVENIENTE SUL LUNGO TERMINE");
                    Console.WriteLine(famiglia.ConvenienzaBolletta(caldaia.CalcoloBolletta(mediaGas), caldaiaCond.CalcoloBolletta(mediaGas), pompaCaloreBuona.CalcoloBolletta(mediaGas), pompaCaloreEco.CalcoloBolletta(mediaGas), stufa.CalcoloBolletta(mediaGas)));
                    Console.WriteLine("----------------------------------------------------------------------------------------");

                    break;

                case "5":
                    do
                    {
                        Console.WriteLine("Inserisci la media annuale di ELETTRICITA' che la famiglia consuma:");
                        res = Console.ReadLine();
                        controllo = Double.TryParse(res, out mediaElettricita);
                    } while (!controllo || mediaElettricita < 0);
                    mediaGas = stufa.OmogeneitaConsumo(mediaElettricita / 10.7);

                    Console.WriteLine("----------------------------------------------------------------------------------------");
                    Console.WriteLine("TEMPO AMMORTIZZAMENTO");
                    Console.WriteLine("Rispetto alla caldaia tradizionale: " + famiglia.Convenienza(stufa.CalcoloBolletta(mediaGas), caldaia.CalcoloBolletta(mediaGas), caldaia.CalcoloTotaleSpesa()));
                    Console.WriteLine("Rispetto alla caldaia a condensazione: " + famiglia.Convenienza(stufa.CalcoloBolletta(mediaGas), caldaiaCond.CalcoloBolletta(mediaGas), caldaiaCond.CalcoloTotaleSpesa()));
                    Console.WriteLine("Rispetto alla pompa di calore di buon livello: " + famiglia.Convenienza(stufa.CalcoloBolletta(mediaGas), pompaCaloreBuona.CalcoloBolletta(mediaGas), pompaCaloreBuona.CalcoloTotaleSpesa()));
                    Console.WriteLine("Rispetto alla pompa di calore economica: " + famiglia.Convenienza(stufa.CalcoloBolletta(mediaGas), pompaCaloreEco.CalcoloBolletta(mediaGas), pompaCaloreEco.CalcoloTotaleSpesa()));
                    Console.WriteLine("----------------------------------------------------------------------------------------");

                    Console.WriteLine("CALCOLO BOLLETTA PIU' CONVENIENTE SUL LUNGO TERMINE");
                    Console.WriteLine(famiglia.ConvenienzaBolletta(caldaia.CalcoloBolletta(mediaGas), caldaiaCond.CalcoloBolletta(mediaGas), pompaCaloreBuona.CalcoloBolletta(mediaGas), pompaCaloreEco.CalcoloBolletta(mediaGas), stufa.CalcoloBolletta(mediaGas)));
                    Console.WriteLine("----------------------------------------------------------------------------------------");

                    break;
            }

            Console.ReadKey();
        }
    }
}
